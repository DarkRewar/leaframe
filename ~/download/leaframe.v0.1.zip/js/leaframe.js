if(typeof jQuery != 'undefined'){
    $.fn.extend({
        overflow: function(type){
            if($(this).css('overflow') != 'hidden'){
                $(this).css({'overflow':'hidden'});
            }else{
                $(this).css({'overflow':'auto'});
            }
        },
        fadeTop: function(e){
            if($(this).is(':visible')){
                $('.out-modal').fadeOut();
                $(this).animate({'top':'-250px'}).fadeOut();
            }else{
                $('.out-modal').fadeIn();
                $(this).animate({'top':'50px'}).show();
            }
        },
        drop: function(e){
            var id = '#'+$(this).attr('drop');
            if($(id).is(':visible')){
                $(id).hide();
            }else{
                $(id).show();
                if($(this).parents('.bottom').length > 0){
                    var h = $(id).height();
                    $(id).css({'margin-top':'-'+h+'px'});
                }else if($(this).parents('.right').length > 0){
                    var w = $(id).width();
                    $(id).css({'margin-left':'-'+w+'px'});
                }else if($(this).parents('.left').length > 0){
                    var w = $(id).width();
                    $(id).css({'margin-left':w+'px'});
                }
            }
        },
        modal: function(e){
            var id = '#'+$(this).attr('modal');
            if($('.out-modal').length == 0){
                $('body').append('<div class="out-modal"></div>');
            }
            $(id).fadeTop();
        },
        theaterDraw: function(stat){
            if(typeof stat == 'undefined') stat = '';
            //$('body').overflow();
            if($(this).is(':visible') || stat == 'hide'){
                var dis = $(this);
                $('.theater-scene').animate({"top":"-75%"}, function(){
                    $(this).hide();
                    dis.hide();
                });
                $('.theater-links').animate({"bottom":"-25%"}, function(){
                    $(this).hide();
                    dis.hide();
                });
            }else{
                $(this).show();
                var scene = $(this).find('.theater-scene');
                var links = $(this).find('.theater-links');

                scene
                    .show()
                    .animate({"top":"0"});

                links
                    .show()
                    .animate({'bottom':'0'});
            }
        },
        theater: function(e){
            var id = $(this).parents('[theater]').attr('theater');
            var iid = '#'+id;

            var img = $(this).html();

            if($(iid).length == 0){
                $('body').append('<div class="theater" id="'+id+'">'+
                    '<div class="theater-scene" id="'+id+'-scene">'+
                    '<a class="close">&times;</a>'+
                    img+
                    '</div>'+
                    '<div class="theater-links" id="'+id+'-links"></div>'+
                    '</div>');
            }else{
                $(iid).html('<div class="theater-scene" id="'+id+'-scene">'+
                    '<a class="close">&times;</a>'+
                    img+
                    '</div>'+
                    '<div class="theater-links" id="'+id+'-links"></div>');
            }
            $('[theater="'+id+'"]')
                    .find('li img')
                    .each(function(){
                        var limg = $(this).attr('src');
                        $(iid+'-links').append(
                            $('<li />')
                                .attr('to-change',id+'-scene')
                                .append(
                                    $('<img />').attr('src',limg)
                                )
                        );
                    });

            $(iid).theaterDraw();
        }
    });

    $(document).ready(function(){
        $('[drop]').hover(function(){
            $(this).drop();
        }, function(){
            $(this).drop();
        });

        $('.message .close').click(function(){
            $(this)
                .parent('.message')
                .fadeOut(500,function(){
                    $(this).remove();
                });
        });

        $('[modal]').click(function(){
            $(this).modal();
        });

        $('body')
            .on('click', '.modal .close', function(){
                $(this)
                    .parent('.modal')
                    .fadeTop();
            })
            .on('click', '.out-modal', function(){
                $('.modal').fadeTop();
            })
            .on('click', '[theater] li', function(){
                $(this).theater();
            })
            .on('click', '.theater .close', function(){
                $(this)
                    .parents('.theater')
                    .theaterDraw();
            })
            .on('keydown', function(e){
                if(e.which==27){
                    $('.theater').theaterDraw('hide');
                }
            })
            .on('click', '[to-change]', function(){
                var url = $(this).find('img').attr('src');
                var id = $(this).attr('to-change');
                $('#'+id).find('img').attr('src', url);
            });
    });
}